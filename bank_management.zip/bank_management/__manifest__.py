{
    'name': "Bank Management System",
    'version': '16.0.0.0',
    'summary':'management bank account',
    'author': 'lamia',
    'description': 'A simple bank management system with required Odoo features.',
    'depends': ['base','sale'],
    "data": [
        'security/ir.model.access.csv',
        'views/bank_account_views.xml',
        'views/customer_views.xml',
        'views/menu_action.xml',
    ],
    'installable': True,
    'application': True,
}
