from odoo import models, fields

class InheritedResPartner(models.Model):
    _inherit = 'res.partner'

    bank_account_ids = fields.One2many("bank.account", "customer_id", string="Bank Accounts")
