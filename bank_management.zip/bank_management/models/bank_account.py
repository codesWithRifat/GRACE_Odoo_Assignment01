from odoo import models, fields, api

class BankAccount(models.Model):
    _name = "bank.account"
    _description = "Bank Account"

    name = fields.Char(string="Account Name", required=True)
    balance = fields.Float(string="Balance")
    open_date = fields.Date(string="Open Date")
    account_type = fields.Selection([
        ('savings', 'Savings'),
        ('current', 'Current'),
        ('fixed', 'Fixed Deposit')
    ], string="Account Type", required=True)
    customer_id = fields.Many2one("res.partner", string="Customer")
    transaction_ids = fields.One2many("bank.transaction", "account_id", string="Transactions")

    @api.depends('transaction_ids.amount')
    def _compute_balance(self):
        for record in self:
            record.balance = sum(record.transaction_ids.mapped('amount'))

class BankTransaction(models.Model):
    _name = "bank.transaction"
    _description = "Bank Transaction"

    account_id = fields.Many2one("bank.account", string="Account")
    date = fields.Date(string="Transaction Date")
    amount = fields.Float(string="Amount")
    description = fields.Text(string="Description")
