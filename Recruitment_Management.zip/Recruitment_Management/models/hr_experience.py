from odoo import models, fields

class HrExperience(models.Model):
    _name = 'hr.experience'
    _description = 'Experience'

    applicant_id = fields.Many2one('hr.applicant', string='Applicant')
    company_name = fields.Char(string='Company Name')
    years = fields.Float(string='Years of Experience')