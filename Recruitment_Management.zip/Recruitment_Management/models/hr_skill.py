from odoo import models, fields

class HrSkill(models.Model):
    _name = 'hr.skill'
    _description = 'Skill'

    name = fields.Char(string='Skill Name', required=True)
