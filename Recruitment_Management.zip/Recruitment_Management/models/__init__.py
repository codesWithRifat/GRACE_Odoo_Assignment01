from . import hr_applicant
from . import hr_skill
from . import hr_experience
from . import hr_department_inherit