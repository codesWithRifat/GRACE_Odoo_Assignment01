from odoo import models, fields

class HrDepartment(models.Model):
    _inherit = 'hr.department'
    recruitment_notes = fields.Text(string='Recruitment Notes')