from odoo import models, fields, api
from datetime import date

class HrApplicant(models.Model):
    _name = 'hr.applicant'
    _description = 'Job Applicant'

    name = fields.Char(string='Full Name', required=True)
    age = fields.Integer(string='Age')
    email = fields.Char(string='Email')
    application_date = fields.Date(string='Application Date', default=fields.Date.today)
    status = fields.Selection([
        ('applied', 'Applied'),
        ('interview', 'Interview Scheduled'),
        ('hired', 'Hired'),
        ('rejected', 'Rejected')
    ], string='Status', default='applied')
    
    department_id = fields.Many2one('hr.department', string='Department')
    skill_ids = fields.Many2many('hr.skill', string='Skills')
    experience_ids = fields.One2many('hr.experience', 'applicant_id', string='Experience')

    @api.depends('experience_ids')
    def _compute_total_experience(self):
        for rec in self:
            rec.total_experience = sum(exp.years for exp in rec.experience_ids)

    total_experience = fields.Float(string='Total Experience (Years)', compute='_compute_total_experience')

    @api.onchange('status')
    def _onchange_status(self):
        if self.status == 'hired':
            self.message_post(body="🎉 Applicant has been hired.")
