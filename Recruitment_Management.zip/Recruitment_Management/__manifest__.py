{
    'name': 'Recruitment_Management',
    'version': '16.0.0.1',
    'summary': 'Manage job applicants and recruitment process',
    'description': "Recruitment module with custom fields and views",
    'category': 'Human Resources',
    'author': 'Md Ohidur Rahman',
    'website': 'https://ohidursportfolio.web.app/',
    'depends': ['base', 'hr'],
    'data': [
        'security/ir.model.access.csv',
        'views/hr_applicant_views.xml',
    ],
    'installable': True,
    'application': True,
}
